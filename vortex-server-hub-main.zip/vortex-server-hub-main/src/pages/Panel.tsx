
import Navigation from "@/components/Navigation";
import { MessageSquare } from "lucide-react";

const Panel = () => {
  const handleJoinDiscord = () => {
    window.location.href = "https://discord.gg/enBX6WEz";
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="container mx-auto px-6 pt-32 pb-20">
        <div className="max-w-2xl mx-auto text-center">
          <MessageSquare className="w-16 h-16 text-primary mx-auto mb-6" />
          <h1 className="text-4xl font-bold mb-6 animate-fade-in">Join Our Discord</h1>
          <p className="text-xl text-gray-300 mb-8 animate-fade-in">
            To access your panel, please join our Discord community. Our team will assist you with setting up your account and providing panel access.
          </p>
          <button 
            onClick={handleJoinDiscord}
            className="btn-primary flex items-center space-x-2 mx-auto animate-fade-in"
          >
            <MessageSquare className="w-5 h-5" />
            <span>Join Discord Server</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Panel;
