
import Navigation from "@/components/Navigation";
import ServerPlan from "@/components/ServerPlan";

const plans = [
  {
    name: "Dirt",
    price: 29,
    specs: {
      ram: "2GB",
      cpu: "100%",
      disk: "10GB",
    },
  },
  {
    name: "Grass",
    price: 69,
    specs: {
      ram: "4GB",
      cpu: "150%",
      disk: "20GB",
    },
  },
  {
    name: "Stone",
    price: 100,
    specs: {
      ram: "6GB",
      cpu: "200%",
      disk: "25GB",
    },
  },
  {
    name: "Diamond",
    price: 150,
    specs: {
      ram: "8GB",
      cpu: "400%",
      disk: "30GB",
    },
  },
];

const BuyServer = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Server Plans Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="container mx-auto">
          <h1 className="text-4xl font-bold text-center mb-6 animate-fade-in">Choose Your Server Plan</h1>
          <p className="text-xl text-center text-gray-300 mb-12 max-w-3xl mx-auto animate-fade-in">
            Select the perfect hosting plan for your needs. All plans include 24/7 support, DDoS protection, and instant setup.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {plans.map((plan, index) => (
              <div key={plan.name} className="animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <ServerPlan {...plan} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default BuyServer;
