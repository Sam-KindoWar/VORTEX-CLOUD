
import Navigation from "@/components/Navigation";
import ServerPlan from "@/components/ServerPlan";
import { Server, Shield, Rocket, Globe, Cpu, Database } from "lucide-react";

const plans = [
  {
    name: "Dirt",
    price: 29,
    specs: {
      ram: "2GB",
      cpu: "100%",
      disk: "10GB",
    },
  },
  {
    name: "Grass",
    price: 69,
    specs: {
      ram: "4GB",
      cpu: "150%",
      disk: "20GB",
    },
  },
  {
    name: "Stone",
    price: 100,
    specs: {
      ram: "6GB",
      cpu: "200%",
      disk: "25GB",
    },
  },
  {
    name: "Diamond",
    price: 150,
    specs: {
      ram: "8GB",
      cpu: "400%",
      disk: "30GB",
    },
  },
];

const features = [
  {
    icon: <Shield className="w-12 h-12 text-primary" />,
    title: "DDoS Protection",
    description: "Advanced protection against DDoS attacks to keep your server running smoothly",
  },
  {
    icon: <Rocket className="w-12 h-12 text-primary" />,
    title: "Instant Setup",
    description: "Get your Minecraft server up and running in minutes",
  },
  {
    icon: <Cpu className="w-12 h-12 text-primary" />,
    title: "High Performance",
    description: "Premium hardware ensures optimal performance for your server",
  },
  {
    icon: <Database className="w-12 h-12 text-primary" />,
    title: "Daily Backups",
    description: "Automatic daily backups to keep your data safe",
  },
];

const Index = () => {
  const handleGetStarted = () => {
    window.location.href = "/buy-server";
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 relative overflow-hidden">
        <div className="container mx-auto text-center relative z-10">
          <div className="flex items-center justify-center mb-6">
            <Globe className="w-16 h-16 text-primary animate-pulse" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            Welcome to Vortex Cloud
          </h1>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto animate-fade-in">
            Experience premium Minecraft server hosting with unmatched performance and reliability.
          </p>
          <button onClick={handleGetStarted} className="btn-primary animate-fade-in">
            Get Started Today
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-dark-light">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Vortex Cloud?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="glass p-6 rounded-xl text-center animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <div className="flex justify-center mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Server Plans Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Choose Your Server Plan</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {plans.map((plan, index) => (
              <div key={plan.name} className="animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <ServerPlan {...plan} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 px-6 bg-dark-light">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your Server?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers and experience the power of Vortex Cloud hosting.
          </p>
          <button onClick={handleGetStarted} className="btn-primary">
            Launch Your Server Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default Index;
