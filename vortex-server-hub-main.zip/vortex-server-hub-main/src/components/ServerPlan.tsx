
import { CheckCircle } from "lucide-react";

interface ServerPlanProps {
  name: string;
  price: number;
  specs: {
    ram: string;
    cpu: string;
    disk: string;
  };
}

const ServerPlan = ({ name, price, specs }: ServerPlanProps) => {
  const bdtPrice = Math.round(price * 3.5); // Approximate conversion rate

  const handleSelectPlan = () => {
    window.location.href = "/purchase-plan";
  };

  return (
    <div className="glass p-6 rounded-xl hover:scale-105 transition-transform duration-300">
      <h3 className="text-xl font-semibold mb-4">{name} Plan</h3>
      <div className="space-y-1 mb-6">
        <div className="text-3xl font-bold">₹{price}<span className="text-sm text-gray-400">/month</span></div>
        <div className="text-xl font-semibold text-gray-400">৳{bdtPrice}<span className="text-sm">/month</span></div>
      </div>
      <div className="space-y-4">
        <div className="flex items-center">
          <CheckCircle className="w-5 h-5 text-primary mr-2" />
          <span>{specs.ram} RAM</span>
        </div>
        <div className="flex items-center">
          <CheckCircle className="w-5 h-5 text-primary mr-2" />
          <span>{specs.cpu} CPU</span>
        </div>
        <div className="flex items-center">
          <CheckCircle className="w-5 h-5 text-primary mr-2" />
          <span>{specs.disk} Disk</span>
        </div>
      </div>
      <button onClick={handleSelectPlan} className="btn-primary w-full mt-6">Select Plan</button>
    </div>
  );
};

export default ServerPlan;
